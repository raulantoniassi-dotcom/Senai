import promptSync from 'prompt-sync'
const prompt = promptSync
console.clear()
let escolha = 2

let total = 0
let maior = clientes[0].valor
let menor = clientes[0].valor
let ref = 0
let media 

let cliente = []
let valor = []

import {faturamento} from './calculos'
import {pedidos} from './dados'
import {via} from './funcoes'
import {boasVindas} from './funcoes'
import {menuPrincipal} from './menu'

menuPrincipal()