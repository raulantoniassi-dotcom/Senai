import promptSync from 'prompt-sync'
const prompt = promptSync()
console.clear()

let cliente = []
let valor = []
export const pedido = (cliente, valor) => {

let nome
let j
    nome = prompt("Nome do cliente: ")
    cliente.push(nome)
    console.clear()

        j = Number(prompt("Valor do pedido: "))
        valor.push(j)
    console.clear()
        return {valor, cliente}
}


