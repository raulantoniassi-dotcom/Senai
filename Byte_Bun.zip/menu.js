import promptSync from 'prompt-sync'
const prompt = promptSync
console.clear()

import {boasVindas} from './funcoes.js'
import {pedido} from './dados.js'
import { faturamento } from './calculos.js'
import {via} from './funcoes.js'
let escolha = 2

export const menuPrincipal = () => {
    while(escolha != 0){
    boasVindas()
    escolha = Number(prompt(`
        1- Registrar pedido
        0- Fechar o caixa`))

    if(escolha == 1){
        pedido()
        faturamento()
    }
}

}