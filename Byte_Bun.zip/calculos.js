import promptSync from 'prompt-sync'
const prompt = promptSync
console.clear()
import {pedido} from './dados.js'

    let total = 0
    let maior = clientes[0].valor
    let menor = clientes[0].valor
    let ref = 0
    let media 
export const faturamento = (total, maior, menor, ref, media) => {
    const clientes = pedido()
    

   

   for(let preco of clientes){
total += preco.valor 
maior = preco > maior ? preco : maior
menor = preco < menor ? preco : menor
ref = preco > 20 ? ref + 1 : ref
   }
media = total / clientes.length
maior = clientes
menor = clientes
  

   return {total, maior, menor, ref, media}
}
