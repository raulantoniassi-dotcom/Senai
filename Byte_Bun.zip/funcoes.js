import faturamento from './calculos'
import pedidos from './dados'

export const boasVindas = () => {
    console.log("------------------------")
    console.log("      BYTE & BUN")
    console.log("-------------------------")
}
const gerarDivisor = () => {
        console.log("-------------------------")
}
export const via = () => {
    boasVindas()
    console.log(`
        Faturamento Total: ${total}
        Ticket médio: ${media}
        Pedido de maior valor: ${maior.cliente} R$ ${maior.valor}
        Pedido de menor valor: ${menor.cliente} R$ ${menor.valor}
        Pedidos acima de R$ 20,00: ${ref}`)

}